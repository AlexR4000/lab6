﻿using System;
using System.IO;

// Step 1: Create the Event class (already defined above)
public class Event
{
    public int EventNumber { get; set; }
    public string Location { get; set; }
    public string EventName { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        

        // Step 2: Create an object and assign values
        Event myEvent = new Event
        {
            EventNumber = 1,
            Location = "Calgary",
            EventName = "Tech Competition"
        };

        // Step 3: Serialize the object to a text file
        using (StreamWriter writer = new StreamWriter("event.txt"))
        {
            writer.WriteLine(myEvent.EventNumber);
            writer.WriteLine(myEvent.Location);
            writer.WriteLine(myEvent.EventName);
        }

        // Step 4: Deserialize the object from the text file and display values
        using (StreamReader reader = new StreamReader("event.txt"))
        {
            Event deserializedEvent = new Event
            {
                EventNumber = int.Parse(reader.ReadLine()),
                Location = reader.ReadLine(),
                EventName = reader.ReadLine()
            };

            Console.WriteLine(deserializedEvent.EventNumber);
            Console.WriteLine(deserializedEvent.Location);
            Console.WriteLine(deserializedEvent.EventName);
        }

        // Step 5: Call the ReadFromFile method
        ReadFromFile();
    }

    // Step 5: Create the ReadFromFile method
    public static void ReadFromFile()
    {
        string filePath = "hackathon.txt";
        string word = "Hackathon";

        // Write the word to the file
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.Write(word);
        }

        // Read the first, middle, and last characters
        using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
        {
            // Read the first character
            stream.Seek(0, SeekOrigin.Begin);
            int firstChar = stream.ReadByte();
            Console.WriteLine($"The First Character is: \"{(char)firstChar}\"");

            // Read the middle character
            stream.Seek(word.Length / 2, SeekOrigin.Begin);
            int middleChar = stream.ReadByte();
            Console.WriteLine($"The Middle Character is: \"{(char)middleChar}\"");

            // Read the last character
            stream.Seek(word.Length - 1, SeekOrigin.Begin);
            int lastChar = stream.ReadByte();
            Console.WriteLine($"The Last Character is: \"{(char)lastChar}\"");
        }
    }
}